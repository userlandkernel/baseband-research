/* Automatically generated, don't edit */
/* Generated on: i30s5 */
/* At: Mon, 19 Jun 2006 14:17:44 +0000 */
/* Linux version 2.6.13-15.10-smp (geeko@buildhost) (gcc version 4.0.2 20050901 (prerelease) (SUSE Linux)) #1 SMP Fri May 12 16:21:47 UTC 2006 */

/* Pistachio Kernel Configuration System */

/* Hardware */

/* Basic Architecture */
#undef  CONFIG_ARCH_IA32
#undef  CONFIG_ARCH_IA64
#undef  CONFIG_ARCH_POWERPC
#undef  CONFIG_ARCH_POWERPC64
#define CONFIG_ARCH_AMD64 1
#undef  CONFIG_ARCH_ALPHA
#undef  CONFIG_ARCH_MIPS64
#undef  CONFIG_ARCH_ARM


/* Processor Type */
#undef  CONFIG_CPU_IA32_I486
#undef  CONFIG_CPU_IA32_I586
#undef  CONFIG_CPU_IA32_I686
#undef  CONFIG_CPU_IA32_P4
#undef  CONFIG_CPU_IA32_K8
#undef  CONFIG_CPU_IA32_C3


/* Processor Type */
#define CONFIG_CPU_AMD64_K8 1
#undef  CONFIG_CPU_AMD64_SIMICS


/* Platform */
#define CONFIG_PLAT_PC99 1


/* Miscellaneous */
#define CONFIG_IOAPIC 1
#define CONFIG_MAX_IOAPICS 4
#define CONFIG_APIC_TIMER_TICK 1000



/* Kernel */
#define CONFIG_IPC_FASTPATH 1
#define CONFIG_DEBUG 1
#define CONFIG_EXPERIMENTAL 1

/* Experimental Features */
#define CONFIG_X_PAGER_EXREGS 1
#define CONFIG_IO_FLEXPAGES 1

#undef  CONFIG_IA32_SMALL_SPACES
#define CONFIG_K8_FLUSHFILTER 1
#define CONFIG_PERFMON 1
#define CONFIG_SPIN_WHEELS 1
#define CONFIG_NEW_MDB 1


/* Debugger */
#define CONFIG_KDB 1

/* Kernel Debugger Console */
#undef  CONFIG_KDB_CONS_KBD
#define CONFIG_KDB_CONS_COM 1
#undef  CONFIG_KDB_CONS_SKI

#define CONFIG_KDB_COMPORT 0x3f8
#define CONFIG_KDB_COMSPEED 57600
#define CONFIG_KDB_DISAS 1
#define CONFIG_KDB_ON_STARTUP 1
#define CONFIG_KDB_BREAKIN 1
#define CONFIG_KDB_BREAKIN_BREAK 1
#define CONFIG_KDB_BREAKIN_ESCAPE 1
#undef  CONFIG_KDB_NO_ASSERTS
#define CONFIG_DEBUG_SYMBOLS 1

/* Trace Settings */
#define CONFIG_VERBOSE_INIT 1
#define CONFIG_TRACEPOINTS 1
#define CONFIG_KMEM_TRACE 1
#define CONFIG_TRACEBUFFER 1



/* Code Generator Options */


/* Derived symbols */
#undef  CONFIG_HAVE_MEMORY_CONTROL
#define CONFIG_IS_64BIT 1
#undef  CONFIG_IA32_PGE
#undef  CONFIG_CPU_ALPHA_A21264
#undef  CONFIG_IA32_FXSR
#undef  CONFIG_CPU_ALPHA_A21064
#undef  CONFIG_BIGENDIAN
#undef  CONFIG_IS_32BIT
#undef  CONFIG_SWIZZLE_IO_ADDR
#undef  CONFIG_ARM_BIG_ENDIAN
#undef  CONFIG_IA32_SMALL_SPACES_GLOBAL
#undef  CONFIG_IA32_PSE
#undef  CONFIG_IA32_TSC
#undef  CONFIG_ACPI
#define CONFIG_ALPHA_FASTPATH 1
#define CONFIG_ALPHA_CONSOLE_RESERVE 3211264
#undef  CONFIG_CPU_ALPHA_A21164
#undef  CONFIG_IA32_SYSENTER
#undef  CONFIG_IA32_HTT
/* That's all, folks! */
#define AUTOCONF_INCLUDED
